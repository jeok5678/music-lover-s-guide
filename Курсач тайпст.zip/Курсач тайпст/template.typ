// Academic aliases {{{1

/// subject abbreviations to full names
#let subjects = (
  "ООП": "Об’єктно-орієнтоване програмування",
  "ОПНJ": "Об’єктно-орієнтоване програмування",
  "ОС": "Операційні системи",
  "ПП": "Проектний практикум",
  "СПМ": "Скриптові мови програмування",
  "Ф": "Філософія",
)

/// education program abbreviations to name & number
#let edu_programs = (
  "ПЗПІ": (
    name: "Інженерія програмного забезпечення",
    number: "F2", // Змінено зі 121 на F2 [cite: 585]
  ),
)

// Template formatting functions {{{1

#let nheading(title) = heading(depth: 1, numbering: none, title)

#let hfill(width) = box(width: width, repeat(" ")) 

#let uline(align: center, content) = underline[
  #if align != left { hfill(1fr) }
  #content
  #if align != right { hfill(1fr) }
]

#let bold(content) = text(weight: "bold")[#content]

#let month_gen(month) = (
  "січня", "лютого", "березня", "квітня", "травня", "червня",
  "липня", "серпня", "вересня", "жовтня", "листопада", "грудня",
).at(month - 1)

// Helper functions {{{1

#let img(path, caption, ..sink) = {
  let parts = path.split(".").first().split("/")
  let label_string = if parts.len() <= 2 or parts.at(-1).starts-with(parts.at(-2)) {
    parts.last()
  } else {
    parts.at(-2) + "_" + parts.at(-1)
  }.replace(" ", "_")

  let caption_text = if sink.pos().len() == 0 {
    caption 
  } else if sink.pos().first() == none {
    caption
  } else {
    [#caption (за даними #sink.pos().first())]
  }

  // ОСЬ ЦЬОГО БЛОКУ НЕ ВИСТАЧАЛО:
  figure(
    image(path, width: 80%), // Сама картинка
    caption: caption_text,    // Підпис під нею
  )
}

// Styling {{{1
#let ua_alpha_numbering = "абвгдежиклмнпрстуфхцшщюя".split("") 
#let spacing = 0.95em

#let style(it) = {
  set page(
    paper: "a4",
    margin: (top: 20mm, right: 10mm, bottom: 20mm, left: 25mm),
    number-align: top + right,
    numbering: (..numbers) => {
      if numbers.pos().at(0) != 1 {
        numbering("1", numbers.pos().at(0))
      }
    },
  )

  set text(font: ("Times New Roman", "Liberation Serif"), size: 14pt, hyphenate: false, lang: "uk")
  set par(justify: true, first-line-indent: (amount: 1.25cm, all: true))
  set underline(evade: false)

  set block(spacing: spacing)
  set par(spacing: spacing)
  set par(leading: spacing)

// enums and lists {{{2
  set enum(numbering: "1)", indent: 1.25cm, body-indent: 0.5cm)

  set list(indent: 1.35cm, body-indent: 0.5cm, marker: [--])

  show figure: it => {
    v(spacing * 2, weak: true)
    it
    v(spacing * 2, weak: true)
  }

  set figure.caption(separator: [ -- ])
  show figure.where(kind: table): set figure.caption(position: top)
  show figure.caption.where(kind: table): set align(left)

  show heading.where(level: 1): it => {
    counter(math.equation).update(0)
    counter(figure.where(kind: image)).update(0)
    counter(figure.where(kind: table)).update(0)
    counter(figure.where(kind: raw)).update(0)
    it
  }
  set math.equation(numbering: (..num) => numbering("(1.1)", counter(heading).get().at(0), num.pos().first()))
  set figure(numbering: (..num) => numbering("1.1", counter(heading).get().at(0), num.pos().first()))

  set ref(
    supplement: it => {
      if it == none or not it.has("kind") {
        it
      } else if it.kind == image {
        "див. рис."
      } else if it.kind == table {
        "див. таблицю"
      } else {
        it
      }
    },
  )
  show ref: it => {
    let el = it.element

    if el == none or not el.has("kind") {
      return it
    }
    if el.kind != image and el.kind != table {
      return it
    }

    [(#it)]
  }

  set heading(numbering: "1.1")

  show heading.where(level: 1): it => {
    set align(center)
    set text(size: 14pt, weight: "semibold")

    pagebreak(weak: true)
    upper(it)
    v(spacing * 2, weak: true)
  }
  show heading.where(level: 2): it => {
    set text(size: 14pt, weight: "regular")

    v(spacing * 2, weak: true)
    block(width: 100%, spacing: 0em)[
      #h(1.25cm)
      #counter(heading).display(it.numbering)
      #it.body
    ]
    v(spacing * 2, weak: true)
  }

  show heading.where(level: 3): it => {
    set text(size: 14pt, weight: "regular")

    v(spacing * 2, weak: true)
    block(width: 100%, spacing: 0em)[
      #h(1.25cm)
      #counter(heading).display(it.numbering)
      #it.body
    ]
    v(spacing * 2, weak: true)
  }

  show raw: it => {
    let new_spacing = 0.5em
    set block(spacing: new_spacing)
    set par(
      spacing: new_spacing,
      leading: new_spacing,
    )
    set text(size: 11pt, font: "Courier New", weight: "semibold")

    v(spacing * 2.5, weak: true)
    pad(it, left: 1.25cm)
    v(spacing * 2.5, weak: true)
  }

  it
}

// Coursework template {{{1
#let cw-template(
  doc,
  title: "NONE",
  subject_shorthand: "NONE",
  department_gen: "Програмної інженерії",
  author: (),
  mentors: (),
  edu_program_shorthand: "ПЗПІ",
  task_list: (),
  calendar_plan: (),
  abstract: (),
  bib_path: "bibl.yml",
  appendices: (),
) = {
  set document(title: title, author: author.name)

  show: style

  let bib-count = state("citation-counter", ())
  show cite: it => {
    it
    bib-count.update(((..c)) => (..c, it.key))
  }
  show bibliography: it => {
    set text(size: 0pt)
    it
  }

  let head_mentor = mentors.at(0)
  let edu_program = edu_programs.at(edu_program_shorthand)

  // page 1 {{{2
  [
    #set align(center)
    Міністерство освіти і науки України \
    Харківський національний університет радіоелектроніки \
    #v(2em)
    Кафедра #department_gen

    #v(4em)

    #text(weight: "bold", size: 16pt)[КУРСОВА РОБОТА] \
    #text(weight: "bold")[Пояснювальна записка] \
    #v(2em)
    з дисципліни “#subjects.at(subject_shorthand, default: "Об’єктно-орієнтоване програмування")” \
    #v(1em)
    #title

    #v(3em)

    #align(right)[
      #box(width: 70%, align(left)[
        #if author.gender == "m" { [Виконав:] } else { [Виконала:] } \
        здобувач _1_ року навчання, групи #box(width: 4cm, stroke: (bottom: 0.5pt), outset: (bottom: 2pt))[#align(center)[#author.group]] \
        #v(1em)
        #grid(
          columns: (1fr, 2fr),
          gutter: 10pt,
          align(bottom)[#box(width: 100%, stroke: (bottom: 0.5pt))[]],
          align(bottom)[
            #align(center)[
              #author.name \
              #text(size: 10pt)[(власне ім’я, ПРІЗВИЩЕ)]
            ]
          ]
        )
        #v(1em)
        #grid(
          columns: (auto, 1fr, 2.5fr),
          gutter: 10pt,
          align(bottom)[Керівник],
          align(bottom)[
            #align(center)[
              #box(width: 100%, stroke: (bottom: 0.5pt))[] \
              #text(size: 10pt)[(підпис)]
            ]
          ],
          align(bottom)[
            #align(center)[
              #head_mentor.degree #head_mentor.name \
              #text(size: 10pt)[(посада, власне ім’я, ПРІЗВИЩЕ)]
            ]
          ]
        )
      ])
    ]

    #v(3em)

    #align(right)[
      #box(width: 70%, align(left)[
        Комісія: \
        #v(1em)
        #for mentor in mentors [
          #grid(
            columns: (1fr, 2fr),
            gutter: 10pt,
            align(bottom)[#box(width: 100%, stroke: (bottom: 0.5pt))[]],
            align(bottom)[#mentor.degree #mentor.name]
          )
          #v(0.5em)
        ]
      ])
    ]

    #v(1fr)

    #align(center)[
      Харків #task_list.done_date.display("[year]")
    ]
    #pagebreak()
  ]

  // page 2 {{{2
  {
    set align(center)
    uline[Харківський національний університет радіоелектроніки]
    v(1em)
    grid(
      columns: (100pt, 1fr),
      align: left,
      bold[Кафедра \ Дисципліна \ Спеціальність],
      [
        #uline(align: left, department_gen) \
        #uline(align: left, subjects.at(subject_shorthand, default: "Об’єктно-орієнтоване програмування")) \
        #uline(align: left, [#edu_program.number #edu_program.name])
      ]
    )
    v(1em)
    // Тут жорстко прописано 1 курс та 2 семестр [cite: 1015, 1019]
    grid(
      columns: (1fr, 1fr, 1fr),
      [#bold[Курс] #uline(1)], 
      [#bold[Група] #uline(author.group)], 
      [#bold[Семестр] #uline(2)]
    )

v(1em)
    align(left)[
      1 Тема роботи \
      #uline(title) \
      \
      2 Термін подання здобувачем роботи до захисту #bold[#task_list.done_date.display("[day]") – #month_gen(task_list.done_date.month()) – #task_list.done_date.display("[year]") р.] \
      3 Вихідні дані до роботи \
      #uline(task_list.source) \
      #uline([]) \
      \
      4 Перелік питань, що потрібно опрацювати в роботі \
      #uline(task_list.content) \
      #uline([]) \
    ]
    pagebreak()
  }

  // page 3 {{{2
  {
    align(center, bold[КАЛЕНДАРНИЙ ПЛАН])
    set par(first-line-indent: 0pt)

    linebreak()

    calendar_plan.plan_table

    linebreak()

    grid(
      columns: (5fr, 5fr),
      grid(
        columns: (1fr, 2fr, 1fr),
        gutter: 0.2fr,
        [
          Студент \
          Керівник \
          #align(center)["#underline[#calendar_plan.approval_date.day()]"]
        ],
        [
          #uline(align: center, []) \
          #uline(align: center, []) \
          #uline(align: center, month_gen(calendar_plan.approval_date.month()))
        ],
        [
          \ \
          #underline[#calendar_plan.approval_date.year()] р.
        ],
      ),
      [
        #author.name, \
        #head_mentor.degree
        #head_mentor.name.
      ],
    )

    pagebreak()
  }

// page 4 {{{2
  [
    #align(center, bold[РЕФЕРАТ]) \
    \
    #context [
      #let pages = counter(page).final().at(0)
      Пояснювальна записка до курсової роботи: #pages с.
    ]
    
    \ \
    #abstract.keywords.join(", ")
    
    \ \
    #abstract.text
    
    #pagebreak()
  ]

  // page 5 {{{2
  outline(
    title: [
      ЗМІСТ
      #v(spacing * 2, weak: true)
    ],
    depth: 2,
    indent: auto,
  )

  doc

// bibliography {{{2
  {
    heading(depth: 1, numbering: none)[Перелік джерел посилання]

    bibliography(
      bib_path,
      style: "ieee",
      full: true,
      title: none,
    )

    let bib_data = yaml(bib_path)

    let format-entry(citation) = {
      if citation.type == "Web" {
        let date_str = ""
        // Безпечна перевірка: чи це об'єкт дати, чи звичайний текст
        if type(citation.url.date) == datetime {
          date_str = citation.url.date.display("[day].[month].[year]")
        } else {
          let d_str = str(citation.url.date)
          let parts = d_str.split("-")
          if parts.len() == 3 {
            date_str = parts.at(2) + "." + parts.at(1) + "." + parts.at(0)
          } else {
            date_str = d_str
          }
        }
        [#citation.title. #citation.author. URL: #citation.url.value (дата звернення: #date_str).]
      } else if citation.type == "Book" [
        #citation.author #citation.title. #citation.publisher, #citation.date. #citation.page-total c.
      ] else [
        [НЕВІДОМИЙ ТИП ДЖЕРЕЛА]
      ]
    }

    context [
      // Збираємо посилання сумісно з усіма версіями Typst
      #let cites = query(cite).map(c => str(c.key))
      #let refs = query(ref.where(element: none)).map(r => str(r.target))
      #let all_citations = (cites + refs).dedup()
      
      #let keys_to_print = if all_citations.len() > 0 { all_citations } else { bib_data.keys() }

      #for (i, key) in keys_to_print.enumerate() {
        let item = bib_data.at(key, default: none)
        if item != none [
          #set par(first-line-indent: 0pt)
          #box(width: 1.25cm)
          #box(width: 1em + 0.5cm)[#(i + 1).]
          #format-entry(item)
          #linebreak()
        ]
      }
    ]
  }

  // appendices {{{2
  {
    counter(heading).update(0)

    set heading(
      numbering: (i, ..nums) => {
        let char = upper(ua_alpha_numbering.at(i))
        if nums.pos().len() == 0 { char } else {
          char + "." + nums.pos().map(str).join(".")
        }
      },
    )

    show heading.where(level: 1): it => {
      set align(center)
      set text(size: 14pt, weight: "regular")

      pagebreak(weak: true)
      bold[ДОДАТОК #counter(heading).display(it.numbering)]
      linebreak()
      it.body
      v(spacing * 2, weak: true)
    }

    show heading.where(level: 2): it => {
      set text(size: 14pt, weight: "regular")

      v(spacing * 2, weak: true)
      block(width: 100%, spacing: 0em)[
        #h(1.25cm)
        #counter(heading).display(it.numbering)
        #it.body
      ]
      v(spacing * 2, weak: true)
    }

    appendices
  }
}

// Laboratory work template {{{1
#let lab-pz-template(
  doc,
  doctype: "NONE",
  title: "NONE",
  subject_shorthand: "NONE",
  department_gen: "Програмної інженерії",
  worknumber: 1,
  authors: (),
  mentor: (),
) = {
  set document(title: title, author: authors.at(0).name)

  show: style

  context counter(heading).update(worknumber - 1)

  // page 1 {{{2
  align(center)[
    МІНІСТЕРСТВО ОСВІТИ І НАУКИ УКРАЇНИ \
    ХАРКІВСЬКИЙ НАЦІОНАЛЬНИЙ УНІВЕРСИТЕТ РАДІОЕЛЕКТРОНІКИ

    \ \
    Кафедра #department_gen

    \ \ \
    Звіт \
    з
    #if doctype == "ЛБ" [лабораторної роботи] else [практичної роботи]
    #if worknumber != none [№ #worknumber]

    з дисципліни: "#subjects.at(subject_shorthand, default: "UNLNOWN SUBJECT, PLEASE OPEN AN ISSUE")"

    з теми: "#title"

    \ \ \ \

    #columns(2)[
      #set align(left)
      #set par(first-line-indent: 0pt)
      #if authors.len() == 1 {
        let author = authors.at(0)
        if author.gender == "m" [Виконав:\ ] else [Виконала:\ ]
        [
          ст. гр. #author.group\
          #author.name\
        ]
        if author.variant != none [Варіант: №#author.variant]
      } else [
        Виконали:\
        ст. гр. #authors.at(0).group\
        #authors.map(a => [ #a.name\ ])
      ]

      #colbreak()
      #set align(right)

      #if mentor.gender == "m" { [Перевірив:\ ] } else { [Перевірила:\ ] }
      #mentor.degree #if mentor.degree.len() >= 15 [\ ]
      #mentor.name\
    ]

    #v(1fr)

    Харків -- #datetime.today().display("[year]")
  ]

  pagebreak(weak: true)

  heading(title)
  doc
}